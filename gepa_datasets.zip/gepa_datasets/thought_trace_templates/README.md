# Thought-Trace Templates

Purpose: Provide Self-Tracing style event templates for an Ethical and an OOD case.
Files: `ethical_icubed.jsonl`, `ood_injection.jsonl`
